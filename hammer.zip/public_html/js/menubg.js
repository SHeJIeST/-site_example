document.getElementById('menu__btn').onclick = function() {
    if (document.getElementById('menu__bg').classList.contains('menu__bg')) {
      document.getElementById('menu__bg').classList.remove('menu__bg');
    }else{
      document.getElementById('menu__bg').classList.add('menu__bg');
    }
  }